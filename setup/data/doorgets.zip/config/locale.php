<?php

$arrLangue = array(
    
    'en' => 'English',
    'fr' => 'Français',
    'de' => 'Deutsch',
    'es' => 'Español',
    'pl' => 'Polski',
    'uk' => 'Український',
    'ru' => 'Pусский',
    'tu' => 'Türk',
    'po' => 'Português',
    'su' => 'Svenska',
    'it' => 'Italiano',
    'it' => 'Italiano',
    'sk' => 'Slovenčina',
    'id' => 'Indonesia',
    'hi' => 'हिंदी',
    'ja' => '日本の',
    'ko' => '한국의',
    'th' => 'ภาษาไทย',
    'cn' => '中国',
    'iw' => 'עברית',
    'ar' => 'العربية'

);