<?php 

$statusPayment['payment_success'] 	= $this->doorGets->__('Paiement reçu');
$statusPayment['subscription_proccess'] 	= $this->doorGets->__('Abonnement');
$statusPayment['payment_cancel'] 	= $this->doorGets->__('Annuler');
$statusPayment['fraud'] 			= $this->doorGets->__('Fraude');
$statusPayment['waiting'] 			= $this->doorGets->__('En attente');
$statusPayment['waiting_transfer'] 	= $this->doorGets->__('En attente du virement');
$statusPayment['waiting_check'] 	= $this->doorGets->__('En attente du chéque');
$statusPayment['waiting_cash'] 		= $this->doorGets->__('En attente du cash');