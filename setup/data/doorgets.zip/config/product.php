<?php 

$productType = array(
	'simple' 			=> $this->doorGets->__('Produit standard'),
	'dematerialized' 	=> $this->doorGets->__('Produit dématérialisé'),
	'pack' 				=> $this->doorGets->__('Pack de produits existants')
);