<?php


$balises = array(
	'body',
    'div',
    'a',
    'img',
    'ul',
    'li',
    'span',
    'p',
    'b',
);

$attributes = array(
	'role',
    'src',
    'data-ride',
    'data-interval',
    'data-slide',
    'data-spy',
    'data-target',
    'data-offset-top',
    'data-offset-bottom',
    'data-src',
    'data-toggle',
    'data-placement',
    'target'
);